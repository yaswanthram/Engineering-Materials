var http = require("http");
var dt = new Date();

http.createServer(function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/plain'});
   response.end('Hello World '+ dt.myDateTime());
   
}).listen(8081);

// Console will print the message
console.log('Server running at 8081');